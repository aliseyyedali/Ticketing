﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Security.Claims;
using Ticketing.Application.Persistence;
using Ticketing.Authentication;
using Ticketing.Domain.Models;
using Ticketing.Persistence;

namespace Ticketing.Controllers
{
    [ApiController]
    [Route("Tickets")]
    [Authorize]
    public class TicketsController(ITicketRepository ticketRepository, IUserRepository userRepository) : ControllerBase
    {
        [HttpGet]
        [Route("my")]
        [RoleAuthorize(UserRole.Employee)]
        public async Task<IActionResult> GetMyTickets()
        {
            try
            {
                var tickets = await ticketRepository.GetAll();
                var myTickets = tickets.Where(t => t.CreatedByUserId == GetUserId()).ToList();
                return Ok(tickets);
            }
            catch (Exception)
            {
                return Problem();
            }

        }

        [HttpGet]

        [RoleAuthorize(UserRole.Admin)]
        public async Task<IActionResult> GetTickets()
        {
            try
            {
                var tickets = await ticketRepository.GetAll();

                return Ok(tickets);
            }
            catch (Exception)
            {
                return Problem();
            }

        }

        [HttpPost]
        [RoleAuthorize(UserRole.Employee)]
        public async Task<IActionResult> CreateTicket(TicketCreateDto dto)
        {
            try
            {
                var userId = GetUserId();
                if (userId == null) return Unauthorized();

                var ticket = new Ticket
                {
                    Id = Guid.NewGuid(),
                    Title = dto.Title,
                    Description = dto.Description,
                    Status = TicketStatus.Open,
                    Priority = dto.Priority,
                    CreatedAt = DateTime.Now,
                    UpdatedAt = DateTime.Now,
                    CreatedByUserId = userId.Value,
                    AssignedToUserId = dto.AssignedToUserId,
                };

                await ticketRepository.Save(ticket);

                return Ok();
            }
            catch (Exception)
            {
                return Problem();
            }

        }

        [HttpGet]
        [Route("status")]
        [RoleAuthorize(UserRole.Admin)]
        public async Task<IActionResult> GetTicketCounts()
        {
            try
            {
                var tickets = await ticketRepository.GetAll();
                var TicketsCount = tickets.GroupBy(t => t.Status).Select(t => new { status = t.Key.ToString(), count = t.Count() });
                return Ok(TicketsCount);
            }
            catch (Exception)
            {
                return Problem();
            }

        }

        [RoleAuthorize(UserRole.Admin)]
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTicket(Guid id, [FromBody] TicketUpdateDto dto)
        {
            try
            {
                var ticket = await ticketRepository.GetById(id);
                if (ticket == null)
                    return NotFound("یافت نشد");


                if (dto.Status.HasValue)
                    ticket.Status = dto.Status.Value;

                if (dto.AssignedToUserId.HasValue)
                    ticket.AssignedToUserId = dto.AssignedToUserId.Value;

                ticket.UpdatedAt = DateTime.UtcNow;

                await ticketRepository.Update(ticket);

                return Ok(null);
            }
            catch (Exception)
            {
                return Problem();
            }

        }

        private Guid? GetUserId()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
            if (userIdClaim == null) return null;

            if (Guid.TryParse(userIdClaim.Value, out var userId))
                return userId;

            return null;
        }
    }

    public class TicketCreateDto
    {
        public string Title { get; set; } = null!;
        public string Description { get; set; } = null!;
        public TicketPriority Priority { get; set; }
        public Guid? AssignedToUserId { get; set; }
    }

    public class TicketUpdateDto
    {
        public TicketStatus? Status { get; set; }
        public Guid? AssignedToUserId { get; set; }
    }
}
