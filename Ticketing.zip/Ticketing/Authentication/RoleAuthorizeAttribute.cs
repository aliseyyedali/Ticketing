﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Linq;
using System.Security.Claims;
using Ticketing.Application.Persistence;
using Ticketing.Domain.Models;


namespace Ticketing.Authentication
{
    public class RoleAuthorizeAttribute : Attribute, IAuthorizationFilter
    {
        private readonly UserRole[] _roles;

        public RoleAuthorizeAttribute( params UserRole[] roles)
        {
            _roles = roles;
        }

        public async void OnAuthorization(AuthorizationFilterContext context)
        {

            var user = context.HttpContext.User;

            if (!user.Identity?.IsAuthenticated ?? true)
            {
                context.Result = new UnauthorizedResult();
                return;
            }
            var userRole = context.HttpContext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role);
            int role = -1;
            if (int.TryParse(userRole.Value, out int _role))
                role = _role;
            bool hasRole = _roles.Contains((UserRole)role);

            if (!hasRole)
            {
                context.Result = new ForbidResult();
            }
        }
    }
}



