﻿using System.Text.Json.Serialization;

namespace Ticketing.Domain.Models
{
    public class Ticket
    {
        public Guid Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public TicketStatus Status { get; set; }
        public TicketPriority Priority { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public Guid CreatedByUserId { get; set; }
        [JsonIgnore]
        public User CreatedByUser { get; set; } = null!;

        public Guid? AssignedToUserId { get; set; }
        [JsonIgnore]
        public User? AssignedToUser { get; set; }

    }

    public enum TicketStatus
{
    Open, InProgress, Closed
}
    public enum TicketPriority
    {
        Low, Medium, High
    }

}
