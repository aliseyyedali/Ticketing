﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel;

namespace Ticketing.Domain.Models
{
    public class User
    {
        public Guid Id { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        [PasswordPropertyText]
        public string Password { get; set; }
        public UserRole Role { get; set; }
        public List<Ticket> CreatedTickets { get; set; } = new();
        public List<Ticket> AssignedTickets { get; set; } = new();
    }
    public enum UserRole
    {
        Admin, Employee

    }
}
