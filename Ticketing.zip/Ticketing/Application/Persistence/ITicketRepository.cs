﻿using Ticketing.Domain.Models;

namespace Ticketing.Application.Persistence
{
    public interface ITicketRepository
    {
        Task<Ticket> GetById(Guid id);
        Task<IEnumerable<Ticket>> GetAll();
        Task Save(Ticket ticket);
        Task Update(Ticket ticket);
    }
}
