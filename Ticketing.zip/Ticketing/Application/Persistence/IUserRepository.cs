﻿using Ticketing.Domain.Models;

namespace Ticketing.Application.Persistence
{
    public interface IUserRepository
    {
        Task<User> GetById(Guid id);
    }
}
