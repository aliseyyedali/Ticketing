﻿using Microsoft.EntityFrameworkCore;
using Ticketing.Application.Persistence;
using Ticketing.Domain.Models;

namespace Ticketing.Persistence.Repositories
{
    public class UserRepository(TicketingContext ticketingContext) : IUserRepository
    {
        public async Task<User> GetById(Guid id)
        {
            return await ticketingContext.Users.Where(u => u.Id == id).FirstOrDefaultAsync();
        }
    }
}
