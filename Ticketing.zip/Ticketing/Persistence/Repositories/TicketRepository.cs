﻿using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using Ticketing.Application.Persistence;
using Ticketing.Domain.Models;

namespace Ticketing.Persistence.Repositories
{
    public class TicketRepository(TicketingContext ticketingContext) : ITicketRepository
    {

        public async Task<Ticket> GetById(Guid id)
        {
            return ticketingContext.Tickets.Where(x => x.Id == id).FirstOrDefault();
        }
        public async Task<IEnumerable<Ticket>> GetAll()
        {
            return ticketingContext.Tickets
                .Include(t => t.CreatedByUser)
                .Include(t => t.AssignedToUser);
        }
        public async Task Save(Ticket ticket)
        {
            ticketingContext.Tickets.Add(ticket);
            await ticketingContext.SaveChangesAsync();
        }

        public async Task Update(Ticket ticket)
        {
            ticketingContext.Entry(ticket).State = EntityState.Modified;
            await ticketingContext.SaveChangesAsync();
        }

    }
}
